
from carla.agent.agent import Agent
from carla.client import VehicleControl
import random
from carla.util import print_over_same_line


class ForwardAgent(Agent):

    def __init__(self, steer, throttle):
        self.steer = steer
        self.throttle = throttle


    """
    Simple derivation of Agent Class,
    A trivial agent agent that goes straight
    """
    def run_step(self, measurements, sensor_data, directions, target):
        control = VehicleControl()
        #control.throttle = 0.9
        self.print_measurements(measurements)
        #print("=====Lidar data======")
        #print(sensor_data['Lidar32'].horizontal_angle)
        #control = measurements.player_measurements.autopilot_control
        control.steer = self.steer
        control.throttle = self.throttle
        return control

    def print_measurements(self, measurements):
     number_of_agents = len(measurements.non_player_agents)
     player_measurements = measurements.player_measurements
     message = 'Vehicle at ({pos_x:.1f}, {pos_y:.1f}), '
     message += '{speed:.0f} km/h, '
     message += 'Collision: {{vehicles={col_cars:.0f}, pedestrians={col_ped:.0f}, other={col_other:.0f}}}, '
     message += '{other_lane:.0f}% other lane, {offroad:.0f}% off-road, '
     message += '({agents_num:d} non-player agents in the scene)'
     message = message.format(
        pos_x=player_measurements.transform.location.x,
        pos_y=player_measurements.transform.location.y,
        speed=player_measurements.forward_speed * 3.6, # m/s -> km/h
        col_cars=player_measurements.collision_vehicles,
        col_ped=player_measurements.collision_pedestrians,
        col_other=player_measurements.collision_other,
        other_lane=100 * player_measurements.intersection_otherlane,
        offroad=100 * player_measurements.intersection_offroad,
        agents_num=number_of_agents)
     print_over_same_line(message)
