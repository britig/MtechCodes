#!/usr/bin/env python3

# Copyright (c) 2017 Computer Vision Center (CVC) at the Universitat Autonoma de
# Barcelona (UAB).
#
# This work is licensed under the terms of the MIT license.
# For a copy, see <https://opensource.org/licenses/MIT>.

"""Basic Bayes Optimisation client example."""

import GPy
import GPyOpt
from numpy.random import seed
import matplotlib
import my_driving_experiment
from matplotlib.pyplot import *

steer_list = []
throt_list = []
collision_sc = []
#Function defination of minimizing distance
#Position of car minus the distance if it is less than 0 there is a collision
def myf(bounds):
    global steer_list
    global throt_list
    global collision_sc
    steering = bounds[0][0]
    throttle = bounds[0][1]
    #[-0.15176541  0.62693194]
    steer_list.append(steering)
    throt_list.append(throttle)
    ped_coll = my_driving_experiment.main(steering, throttle)
    collision_sc.append(ped_coll)
    print(ped_coll)
    return -ped_coll

#Variable declaration for the car
#delta_t = 0.025
#Position of the obstacle
x_obs=10
#Domain of uncertainity position of car
bounds = [{'name': 'steering', 'type': 'continuous', 'domain': (-0.5,0.0)}, {'name': 'throttle', 'type': 'continuous', 'domain': (0.5,0.8)}]
#Budget number of evaluations of f
max_iter = 100
# Creates GPyOpt object with the model and acquisition fucntion
seed(123)
myProblem = GPyOpt.methods.BayesianOptimization(myf,     # function to optimize  
                                                bounds,  # box-constraints of the problem
                                                acquisition_type='EI',
                                                exact_feval = True) # Selects the Expected improvement
max_time = 100     # time budget 
eps      = 10e-10  # Minimum allowed distance between the last two observations

myProblem.run_optimization(max_iter, max_time, eps)
print(myProblem.x_opt)
print(myProblem.fx_opt)
print(steer_list)
print(throt_list)
print(collision_sc)
myProblem.plot_convergence()
figure()
plot(collision_sc, steer_list, 'g*')
xlabel('collision_score')
ylabel('steering')
title('collision_score vs steering')
show()
figure()
plot(collision_sc, throt_list, 'g*')
xlabel('collision_score')
ylabel('throt_list')
title('collision_score vs throttle')
show()

